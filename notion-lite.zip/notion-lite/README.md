        # Notion-lite (Vite + React + Tailwind)

        Быстрый старт:

1. Установите зависимости:

```
npm install
```

2. Запустите dev сервер:

```
npm run dev
```

Откройте указанный адрес (обычно http://localhost:5173)

Проект использует localStorage для сохранения страниц.

Tailwind уже настроен — если хотите изменить дизайн, правьте `src/index.css` и `tailwind.config.cjs`.
